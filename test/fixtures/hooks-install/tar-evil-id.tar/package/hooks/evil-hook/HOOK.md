---
name: evil-hook
description: evil-hook
metadata: {"operator":{"events":["command:new"]}}
---

# Hook