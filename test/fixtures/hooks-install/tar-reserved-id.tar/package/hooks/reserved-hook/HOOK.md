---
name: reserved-hook
description: reserved-hook
metadata: {"operator":{"events":["command:new"]}}
---

# Hook