---
name: tar-hook
description: tar-hook
metadata: {"operator":{"events":["command:new"]}}
---

# Hook